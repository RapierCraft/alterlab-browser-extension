/**
 * AlterLab Connect - Background Service Worker
 *
 * Orchestrates:
 * - Side panel lifecycle
 * - Badge management (scrape complexity score)
 * - Context menu creation ("Scrape this element", "Copy selector")
 * - Message routing between popup, side panel, and content scripts
 */

importScripts("shared.js");

const BADGE_ALARM_NAME = "alterlab-badge-refresh";
const BADGE_REFRESH_MINUTES = 30;
const SESSION_STALENESS_ALARM = "alterlab-session-staleness";
const SESSION_STALENESS_MINUTES = 60;

// Per-tab storage for security header signals detected via webRequest
const tabHeaderSignals = new Map();

// Per-tab storage for raw response headers (used by content script anti-bot detection)
const tabResponseHeaders = new Map();

// Per-tab ring buffer for network request/response headers (Headers tab)
const MAX_REQUESTS_PER_TAB = 200;
const tabNetworkRequests = new Map(); // tabId -> { requests: [], pending: Map }

// ---------------------------------------------------------------------------
// Extension lifecycle
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("[AlterLab] Extension installed.");
    chrome.action.setBadgeBackgroundColor({ color: "#6366f1" });

    // Set first-run flags — overlay will show once on first side panel open
    chrome.storage.local.set({
      firstRunComplete: false,
      hasSeenOverlay: false,
    });

    // Open welcome tab — tells user they're all set, close tab and browse
    chrome.tabs.create({
      url: "https://alterlab.io/welcome?source=extension",
      active: true,
    });
  } else if (details.reason === "update") {
    console.log(
      `[AlterLab] Extension updated to v${chrome.runtime.getManifest().version}`,
    );
  }

  // Set up periodic badge refresh
  chrome.alarms.create(BADGE_ALARM_NAME, {
    periodInMinutes: BADGE_REFRESH_MINUTES,
  });

  // Set up periodic session staleness check
  chrome.alarms.create(SESSION_STALENESS_ALARM, {
    periodInMinutes: SESSION_STALENESS_MINUTES,
  });

  // Create context menus
  createContextMenus();

  // Enable side panel
  chrome.sidePanel
    .setOptions({
      enabled: true,
    })
    .catch(() => {
      // Side panel API might not be available in older Chrome
    });
});

// ---------------------------------------------------------------------------
// Context Menus
// ---------------------------------------------------------------------------

function createContextMenus() {
  // Remove existing menus first to avoid duplicates
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "alterlab-scrape-element",
      title: "Scrape this element",
      contexts: ["all"],
    });

    chrome.contextMenus.create({
      id: "alterlab-copy-selector",
      title: "Copy selector",
      contexts: ["all"],
    });

    chrome.contextMenus.create({
      id: "alterlab-separator",
      type: "separator",
      contexts: ["all"],
    });

    chrome.contextMenus.create({
      id: "alterlab-open-sidepanel",
      title: "Open AlterLab Connect",
      contexts: ["all"],
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "alterlab-open-sidepanel") {
    try {
      await chrome.sidePanel.open({ windowId: tab.windowId });
    } catch {
      // fallback — side panel may already be open
    }
    return;
  }

  if (info.menuItemId === "alterlab-scrape-element") {
    // Send message to content script to get the clicked element's selector
    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: "GET_ELEMENT_SELECTOR",
      });
      if (response && response.selector) {
        // Store selector for side panel Job tab to use
        await chrome.storage.local.set({
          lastElementSelector: response.selector,
          lastElementUrl: tab.url,
        });
        // Open side panel on Job tab
        await chrome.storage.local.set({ sidepanelOpenTab: "job" });
        await chrome.sidePanel.open({ windowId: tab.windowId });
      }
    } catch {
      // Content script not available on this page
    }
    return;
  }

  if (info.menuItemId === "alterlab-copy-selector") {
    try {
      // Inject a small script to copy the element under cursor
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // This runs in the page context — gets the last right-clicked element
          const el = document.querySelector(":hover");
          if (!el) return;

          function getSelector(element) {
            if (element.id) return `#${element.id}`;
            let path = "";
            let current = element;
            while (current && current !== document.body) {
              let sel = current.tagName.toLowerCase();
              if (current.className && typeof current.className === "string") {
                const cls = current.className
                  .trim()
                  .split(/\s+/)
                  .filter((c) => c.length > 0 && !c.includes(":"))
                  .slice(0, 2)
                  .join(".");
                if (cls) sel += "." + cls;
              }
              path = path ? sel + " > " + path : sel;
              current = current.parentElement;
            }
            return path;
          }

          const selector = getSelector(el);
          navigator.clipboard.writeText(selector).catch(() => {
            // Fallback
            const ta = document.createElement("textarea");
            ta.value = selector;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand("copy");
            document.body.removeChild(ta);
          });
        },
      });
    } catch {
      // Cannot execute on this page
    }
    return;
  }
});

// ---------------------------------------------------------------------------
// Message handling
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_COOKIES") {
    handleGetCookies(message.domain, message.url).then(sendResponse);
    return true; // async response
  }

  if (message.type === "BADGE_LOADING") {
    // Show "..." while page analysis is in progress
    chrome.action.setBadgeText({ text: "..." });
    chrome.action.setBadgeBackgroundColor({ color: "#44403c" }); // muted grey
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "BADGE_ERROR") {
    // Show "!" when analysis fails
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#ef4444" }); // error red
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "SCRAPE_SCORE") {
    // Store score and update badge
    const score = message.score;
    const domain = message.domain;
    if (typeof score === "number" && domain) {
      chrome.storage.local.set({ ["scrapeScore_" + domain]: score });
      updateBadgeWithScore(score);
    }
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "CONTENT_SCRIPT_READY") {
    // Content script loaded — request analysis with retry for race conditions
    if (sender.tab && sender.tab.id) {
      requestAnalysisWithRetry(sender.tab.id, sender.tab.active);

      // First page visit after install — auto-open side panel to show score
      chrome.storage.local.get(["firstRunComplete"], (result) => {
        if (result.firstRunComplete === false) {
          chrome.storage.local.set({ firstRunComplete: true });
          // Small delay so the page loads and score computes first
          setTimeout(() => {
            chrome.sidePanel
              .open({ windowId: sender.tab.windowId })
              .catch(() => {
                // Side panel may not be available
              });
          }, 1500);
        }
      });
    }
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "GET_HEADER_SIGNALS") {
    // Side panel requests header signals collected via webRequest
    const signals = tabHeaderSignals.get(message.tabId) || [];
    sendResponse({ signals });
    return false;
  }

  if (message.type === "GET_RESPONSE_HEADERS") {
    // Side panel requests raw response headers for anti-bot detection
    const headers = tabResponseHeaders.get(message.tabId) || null;
    sendResponse({ headers });
    return false;
  }

  if (message.type === "FETCH_URL") {
    handleFetchUrl(message.url)
      .then(sendResponse)
      .catch((err) => sendResponse({ error: err.message, body: null }));
    return true; // async response
  }

  if (message.type === "GET_NETWORK_REQUESTS") {
    // Side panel requests captured network headers for a tab
    const tabData = tabNetworkRequests.get(message.tabId);
    sendResponse({ requests: tabData ? tabData.requests : [] });
    return false;
  }

  if (message.type === "CLEAR_NETWORK_REQUESTS") {
    // Side panel requests clearing the buffer for a tab
    tabNetworkRequests.delete(message.tabId);
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "SESSION_SAVED" || message.type === "CONFIG_UPDATED") {
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "SESSION_PROFILE_COUNT") {
    // Update badge with local session profile count for the active domain
    const count = message.count || 0;
    if (count > 0) {
      chrome.action.setBadgeText({ text: String(count) });
      chrome.action.setBadgeBackgroundColor({ color: "#6366f1" });
    }
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "CONNECTIVITY_RESTORED") {
    replaySyncQueue();
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "SELECTOR_PICKED" || message.type === "SELECTOR_ESCAPED") {
    // Forward from content script to side panel
    notifySidePanels(message);
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "PING") {
    sendResponse({ status: "ok" });
    return false;
  }

  if (message.type === "SCRAPE_PAGE") {
    handleScrapePage(message).then(sendResponse);
    return true; // async response
  }

  if (message.type === "CAPTURE_SCREENSHOT") {
    handleCaptureScreenshot().then(sendResponse);
    return true; // async response
  }
});

// ---------------------------------------------------------------------------
// Tab change — update badge for new tab
// ---------------------------------------------------------------------------

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab && tab.url) {
      const url = new URL(tab.url);
      const domain = url.hostname;
      // Show cached score immediately, then trigger fresh analysis
      chrome.storage.local.get(["scrapeScore_" + domain], (result) => {
        const score = result["scrapeScore_" + domain];
        if (typeof score === "number") {
          updateBadgeWithScore(score);
        } else {
          chrome.action.setBadgeText({ text: "" });
        }
      });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  } catch {
    chrome.action.setBadgeText({ text: "" });
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Clear network requests on new navigation (before page loads)
  if (changeInfo.status === "loading" && tab.url) {
    tabNetworkRequests.set(tabId, { requests: [], pending: new Map() });
  }

  if (changeInfo.status === "loading" && tab.active && tab.url) {
    // Show "..." immediately when a page starts loading
    try {
      const url = new URL(tab.url);
      if (url.protocol === "http:" || url.protocol === "https:") {
        chrome.action.setBadgeText({ text: "..." });
        chrome.action.setBadgeBackgroundColor({ color: "#44403c" });
      }
    } catch {
      // ignore
    }
  }
  if (changeInfo.status === "complete" && tab.active && tab.url) {
    try {
      const url = new URL(tab.url);
      if (url.protocol === "http:" || url.protocol === "https:") {
        // Trigger fresh analysis on every completed page load
        requestAnalysisWithRetry(tabId, true);
      }
    } catch {
      chrome.action.setBadgeText({ text: "" });
    }
  }
});

// Clean up header signals and network requests when tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  tabHeaderSignals.delete(tabId);
  tabResponseHeaders.delete(tabId);
  tabNetworkRequests.delete(tabId);
});

// ---------------------------------------------------------------------------
// Badge Management
// ---------------------------------------------------------------------------

// Track previous badge score for pulse animation
let lastBadgeScore = null;

function updateBadgeWithScore(score) {
  const color = scrapeScoreColor(score);
  chrome.action.setBadgeText({ text: String(score) });
  chrome.action.setBadgeBackgroundColor({ color });

  // Pulse effect: briefly flash badge when score changes between pages
  if (lastBadgeScore !== null && lastBadgeScore !== score) {
    chrome.action.setBadgeBackgroundColor({ color: "#ffffff" });
    setTimeout(() => {
      chrome.action.setBadgeBackgroundColor({ color });
    }, 150);
    setTimeout(() => {
      chrome.action.setBadgeBackgroundColor({ color: "#ffffff" });
    }, 300);
    setTimeout(() => {
      chrome.action.setBadgeBackgroundColor({ color });
    }, 450);
  }
  lastBadgeScore = score;
}

/**
 * Request page analysis from content script with retry logic.
 * The content script may not be ready immediately after navigation,
 * so we retry up to 3 times with exponential backoff.
 */
function requestAnalysisWithRetry(tabId, updateBadge, attempt = 0) {
  const MAX_ATTEMPTS = 3;
  const DELAY_MS = [200, 500, 1000]; // exponential backoff

  // Show "..." on first attempt (loading indicator)
  if (attempt === 0 && updateBadge) {
    chrome.action.setBadgeText({ text: "..." });
    chrome.action.setBadgeBackgroundColor({ color: "#44403c" });
  }

  chrome.tabs
    .sendMessage(tabId, { type: "ANALYZE_PAGE" })
    .then((analysis) => {
      if (analysis && typeof analysis.score === "number") {
        // Merge header signals from webRequest into analysis
        const headerSignals = tabHeaderSignals.get(tabId) || [];
        let adjustedScore = analysis.score;

        for (const signal of headerSignals) {
          if (!analysis.signals.includes(signal.label)) {
            analysis.signals.push(signal.label);
            adjustedScore += signal.score;
          }
        }

        adjustedScore = Math.min(100, Math.max(0, adjustedScore));
        analysis.score = adjustedScore;

        // Store the enriched analysis
        chrome.storage.local.set({
          ["scrapeScore_" + analysis.domain]: analysis.score,
          ["scrapeAnalysis_" + analysis.domain]: analysis,
        });

        if (updateBadge) {
          updateBadgeWithScore(analysis.score);
        }
      }
    })
    .catch(() => {
      // Content script not ready yet — retry with backoff
      if (attempt < MAX_ATTEMPTS) {
        setTimeout(() => {
          requestAnalysisWithRetry(tabId, updateBadge, attempt + 1);
        }, DELAY_MS[attempt] || 1000);
      } else if (updateBadge) {
        // All retries exhausted — show error state
        chrome.action.setBadgeText({ text: "!" });
        chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
      }
    });
}

// ---------------------------------------------------------------------------
// WebRequest Header Analysis
// ---------------------------------------------------------------------------

// Listen for response headers to detect server-side security signals.
// This runs in the background service worker and has access to HTTP headers
// that are invisible to content scripts.
if (chrome.webRequest) {
  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      // Only analyze main frame (document) requests
      if (details.type !== "main_frame") return;

      const signals = [];
      const headers = details.responseHeaders || [];

      for (const header of headers) {
        const name = header.name.toLowerCase();
        const value = (header.value || "").toLowerCase();

        // Server header reveals stack
        if (name === "server") {
          if (value.includes("cloudflare")) {
            signals.push({ label: "Cloudflare CDN", score: 5 });
          } else if (value.includes("akamai") || value.includes("akamaghost")) {
            signals.push({ label: "Akamai CDN", score: 5 });
          }
        }

        // Strict security headers indicate sophistication
        if (
          name === "strict-transport-security" &&
          value.includes("max-age")
        ) {
          signals.push({ label: "HSTS enabled", score: 3 });
        }

        if (name === "content-security-policy" && value.length > 100) {
          signals.push({ label: "Strict CSP policy", score: 5 });
        }

        // X-Frame-Options / frame denial
        if (name === "x-frame-options") {
          signals.push({ label: "X-Frame-Options: " + header.value, score: 2 });
        }

        // WAF / security product headers
        if (name === "x-sucuri-id" || name === "x-sucuri-cache") {
          signals.push({ label: "Sucuri WAF", score: 10 });
        }

        if (name === "x-cdn" && value.includes("imperva")) {
          signals.push({ label: "Imperva CDN", score: 10 });
        }

        // Rate limiting headers
        if (name === "x-ratelimit-limit" || name === "x-rate-limit-limit") {
          signals.push({ label: "Rate limiting active", score: 5 });
        }

        // Bot detection cookies set via headers
        if (name === "set-cookie") {
          if (value.includes("datadome")) {
            signals.push({ label: "DataDome (cookie)", score: 10 });
          }
          if (value.includes("_abck") || value.includes("bm_sz")) {
            signals.push({ label: "Akamai Bot Manager (cookie)", score: 10 });
          }
          if (value.includes("_pxhd") || value.includes("_pxvid")) {
            signals.push({ label: "PerimeterX (cookie)", score: 10 });
          }
        }
      }

      if (signals.length > 0) {
        tabHeaderSignals.set(details.tabId, signals);
      }

      // Store raw response headers for content script anti-bot detection
      // (content scripts can't see HTTP headers directly)
      const headerMap = {};
      for (const h of headers) {
        headerMap[h.name.toLowerCase()] = h.value || "";
      }
      tabResponseHeaders.set(details.tabId, headerMap);

      // Inject headers into page context so content script can access them
      // via window.__alterlabHeaderCache
      if (details.tabId >= 0) {
        try {
          chrome.scripting.executeScript({
            target: { tabId: details.tabId },
            func: (headerData) => {
              window.__alterlabHeaderCache = headerData;
            },
            args: [headerMap],
            injectImmediately: true,
          }).catch(() => {
            // Can't inject into this page (chrome://, extensions, etc.)
          });
        } catch {
          // scripting API not available
        }
      }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders", "extraHeaders"],
  );

  // ---------------------------------------------------------------------------
  // Network Request Capture (Headers tab)
  // ---------------------------------------------------------------------------
  // Capture request headers via onSendHeaders (fires after all modifications)
  chrome.webRequest.onSendHeaders.addListener(
    (details) => {
      if (details.tabId < 0) return; // ignore non-tab requests

      let tabData = tabNetworkRequests.get(details.tabId);
      if (!tabData) {
        tabData = { requests: [], pending: new Map() };
        tabNetworkRequests.set(details.tabId, tabData);
      }

      const entry = {
        requestId: details.requestId,
        url: details.url,
        method: details.method,
        type: details.type,
        timestamp: details.timeStamp,
        requestHeaders: (details.requestHeaders || []).map((h) => ({
          name: h.name,
          value: h.value || "",
        })),
        responseHeaders: [],
        statusCode: 0,
        statusLine: "",
      };

      tabData.pending.set(details.requestId, entry);
    },
    { urls: ["<all_urls>"] },
    ["requestHeaders", "extraHeaders"],
  );

  // Capture response headers and finalize the entry
  chrome.webRequest.onCompleted.addListener(
    (details) => {
      if (details.tabId < 0) return;

      const tabData = tabNetworkRequests.get(details.tabId);
      if (!tabData) return;

      const entry = tabData.pending.get(details.requestId);
      if (entry) {
        entry.responseHeaders = (details.responseHeaders || []).map((h) => ({
          name: h.name,
          value: h.value || "",
        }));
        entry.statusCode = details.statusCode;
        entry.statusLine = details.statusLine || "";
        entry.duration = details.timeStamp - entry.timestamp;

        tabData.pending.delete(details.requestId);

        // Add to ring buffer
        tabData.requests.push(entry);
        if (tabData.requests.length > MAX_REQUESTS_PER_TAB) {
          tabData.requests.shift();
        }
      }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders", "extraHeaders"],
  );

  // Handle errored requests (DNS fail, connection refused, etc.)
  chrome.webRequest.onErrorOccurred.addListener(
    (details) => {
      if (details.tabId < 0) return;

      const tabData = tabNetworkRequests.get(details.tabId);
      if (!tabData) return;

      const entry = tabData.pending.get(details.requestId);
      if (entry) {
        entry.statusCode = 0;
        entry.statusLine = details.error || "Error";
        entry.duration = details.timeStamp - entry.timestamp;

        tabData.pending.delete(details.requestId);

        tabData.requests.push(entry);
        if (tabData.requests.length > MAX_REQUESTS_PER_TAB) {
          tabData.requests.shift();
        }
      }
    },
    { urls: ["<all_urls>"] },
  );
}

// Handle alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === BADGE_ALARM_NAME) {
    // Refresh badge for active tab
    chrome.tabs
      .query({ active: true, currentWindow: true })
      .then(([tab]) => {
        if (tab && tab.url) {
          try {
            const url = new URL(tab.url);
            chrome.storage.local.get(
              ["scrapeScore_" + url.hostname],
              (result) => {
                const score = result["scrapeScore_" + url.hostname];
                if (typeof score === "number") {
                  updateBadgeWithScore(score);
                }
              },
            );
          } catch {
            // ignore
          }
        }
      });
  }

  if (alarm.name === SESSION_STALENESS_ALARM) {
    // Check all session profiles for staleness and notify side panels
    checkSessionProfileStaleness();
  }
});

/**
 * Periodically check session profiles for expired cookies.
 * Sends a notification to open side panels so they can update staleness badges.
 */
async function checkSessionProfileStaleness() {
  try {
    const profiles = await getAllSessionProfiles();
    let staleCount = 0;
    for (const profile of profiles) {
      const result = checkSessionStaleness(profile);
      if (result.stale) staleCount++;
    }
    if (staleCount > 0) {
      notifySidePanels({
        type: "SESSION_STALENESS_UPDATE",
        staleCount,
      });
    }
  } catch {
    // ignore
  }
}

// ---------------------------------------------------------------------------
// URL Fetch (CORS bypass for robots.txt / sitemaps)
// ---------------------------------------------------------------------------

/**
 * Fetch a URL from the background service worker context.
 * This bypasses CORS restrictions since service workers are not subject
 * to the same-origin policy for fetch requests.
 */
async function handleFetchUrl(url) {
  try {
    const resp = await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "AlterLab-Connect/2.0",
        Accept: "text/plain, application/xml, text/xml, */*",
      },
      redirect: "follow",
    });
    if (!resp.ok) {
      return {
        error: `HTTP ${resp.status} ${resp.statusText}`,
        body: null,
        status: resp.status,
      };
    }
    const body = await resp.text();
    return { error: null, body, status: resp.status };
  } catch (err) {
    return { error: err.message || "Network error", body: null, status: 0 };
  }
}

// ---------------------------------------------------------------------------
// Cookie Retrieval (message handler)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Sync Queue Replay — replays queued API requests when connectivity returns
// ---------------------------------------------------------------------------

let _replayInProgress = false;

async function replaySyncQueue() {
  if (_replayInProgress) return;
  _replayInProgress = true;

  try {
    const queue = await getSyncQueue();
    if (queue.length === 0) {
      _replayInProgress = false;
      return;
    }

    console.log(`[AlterLab] Replaying ${queue.length} queued request(s)...`);

    for (const entry of queue) {
      try {
        const resp = await fetch(entry.url, {
          method: entry.method,
          headers: entry.headers,
          body: entry.body ? JSON.stringify(entry.body) : undefined,
        });

        if (resp.ok) {
          // Success — remove from queue and notify side panel
          await removeFromSyncQueue(entry.id);
          const remaining = await getSyncQueueCount();
          notifySidePanels({
            type: "SYNC_RESULT",
            success: true,
            label: entry.label,
            queueType: entry.type,
          });
          notifySidePanels({
            type: "SYNC_QUEUE_UPDATED",
            count: remaining,
          });
          console.log(`[AlterLab] Synced: ${entry.label}`);
        } else {
          // Server error (4xx/5xx) — don't retry, remove from queue
          console.warn(
            `[AlterLab] Sync failed (HTTP ${resp.status}): ${entry.label}`,
          );
          await removeFromSyncQueue(entry.id);
          const remaining = await getSyncQueueCount();
          notifySidePanels({
            type: "SYNC_RESULT",
            success: false,
            label: entry.label,
            error: `HTTP ${resp.status}`,
            queueType: entry.type,
          });
          notifySidePanels({
            type: "SYNC_QUEUE_UPDATED",
            count: remaining,
          });
        }
      } catch (err) {
        // Network error during replay — stop processing, still offline
        console.warn(`[AlterLab] Still offline, stopping replay: ${err.message}`);
        break;
      }
    }
  } finally {
    _replayInProgress = false;
  }
}

/**
 * Send a message to all open side panel / popup instances.
 */
function notifySidePanels(message) {
  chrome.runtime
    .sendMessage(message)
    .catch(() => {
      // No listeners — side panel may be closed
    });
}

// ---------------------------------------------------------------------------
// Cookie Retrieval (message handler)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Screenshot Capture — uses chrome.tabs.captureVisibleTab
// ---------------------------------------------------------------------------

/**
 * Capture a screenshot of the currently visible tab.
 * Must run in the background service worker context where
 * chrome.tabs.captureVisibleTab is available.
 * @returns {Promise<{error: string|null, dataUrl: string|null}>}
 */
async function handleCaptureScreenshot() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (!tab) {
      return { error: "No active tab found", dataUrl: null };
    }

    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: "png",
      quality: 100,
    });

    return { error: null, dataUrl };
  } catch (err) {
    return {
      error: err.message || "Failed to capture screenshot",
      dataUrl: null,
    };
  }
}

// ---------------------------------------------------------------------------
// Scrape Page — One-shot scrape via AlterLab API (CORS bypass)
// ---------------------------------------------------------------------------

/**
 * Handle a SCRAPE_PAGE request from the side panel.
 * Uses the AlterLab API to scrape the given URL and return formatted content.
 *
 * @param {Object} message
 * @param {string} message.url - URL to scrape
 * @param {string} message.format - "markdown" | "html" | "json"
 * @param {string} message.apiKey - API key (empty for anonymous)
 * @param {string} message.apiUrl - Base API URL
 * @param {string} message.deviceId - Device UUID for anonymous tracking
 * @returns {Promise<{error: string|null, content: string|null, jobId: string|null}>}
 */
async function handleScrapePage(message) {
  const { url, format, apiKey, apiUrl, deviceId } = message;
  const baseUrl = apiUrl || ALTERLAB_DEFAULT_API_URL;

  const body = {
    url,
    formats: [format === "html" ? "html" : format === "json" ? "json" : "markdown"],
  };

  const headers = {
    "Content-Type": "application/json",
  };

  if (apiKey) {
    headers["X-API-Key"] = apiKey;
  } else if (deviceId) {
    headers["X-Device-Id"] = deviceId;
  }

  try {
    const resp = await fetch(`${baseUrl}/api/v1/scrape`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    });

    if (!resp.ok) {
      const errBody = await resp.json().catch(() => ({}));
      return {
        error: errBody.detail || `HTTP ${resp.status}: ${resp.statusText}`,
        content: null,
        jobId: null,
      };
    }

    const result = await resp.json();
    const jobId = result.job_id || result.id || null;

    // Extract the content in the requested format
    let content = null;
    if (result.content) {
      content = typeof result.content === "string"
        ? result.content
        : JSON.stringify(result.content, null, 2);
    } else if (result.text) {
      content = result.text;
    } else if (result.markdown) {
      content = result.markdown;
    } else if (result.html) {
      content = result.html;
    } else if (result.data) {
      content = JSON.stringify(result.data, null, 2);
    } else {
      content = JSON.stringify(result, null, 2);
    }

    return { error: null, content, jobId };
  } catch (err) {
    return {
      error: err.message || "Network error — check your connection",
      content: null,
      jobId: null,
    };
  }
}

// ---------------------------------------------------------------------------
// Cookie Retrieval (message handler)
// ---------------------------------------------------------------------------

async function handleGetCookies(domain, url) {
  try {
    const baseDomain = getBaseDomain(domain);
    const domainCookies = await chrome.cookies.getAll({ domain: baseDomain });
    const urlCookies = url ? await chrome.cookies.getAll({ url }) : [];

    const seen = new Set();
    const merged = [];

    for (const cookie of [...domainCookies, ...urlCookies]) {
      const key = `${cookie.name}|${cookie.domain}|${cookie.path}`;
      if (!seen.has(key)) {
        seen.add(key);
        merged.push({
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain,
          path: cookie.path,
          httpOnly: cookie.httpOnly,
          secure: cookie.secure,
          sameSite: cookie.sameSite,
          expirationDate: cookie.expirationDate || null,
        });
      }
    }

    merged.sort((a, b) => a.name.localeCompare(b.name));
    return { cookies: merged, error: null };
  } catch (err) {
    return { cookies: [], error: err.message };
  }
}
